﻿console.log('Hello World! \n 이름: \"홍길동\" \n 소속: 컴퓨터공학부 \n 학번: 20163333');
